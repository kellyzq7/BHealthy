// index.js
const serverless = require("serverless-http");
const express = require("express");
const {
  BedrockRuntimeClient,
  InvokeModelCommand,
} = require("@aws-sdk/client-bedrock-runtime");

const app = express();
app.use(express.json());

// CORS middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

const MOCK_MODE = false; // toggle to false for real AI integration

// ------------------------
// Endpoint: POST /meal-planner
// ------------------------
app.post("/meal-planner", async (req, res) => {
  try {
    const { menu, goal, mealType, diningHall, calorieGoal } = req.body;
    
    // Handle both formats: new frontend format and old format
    const calories = goal?.calories || parseInt(calorieGoal) || 600;
    
    // Use mock menu if none provided
    const menuData = menu || [
      { item: "Grilled Chicken Breast", calories: 250, protein: 35, carbs: 0, fat: 10 },
      { item: "Brown Rice", calories: 200, protein: 4, carbs: 45, fat: 1 },
      { item: "Steamed Broccoli", calories: 50, protein: 4, carbs: 10, fat: 0 },
      { item: "Quinoa Salad", calories: 180, protein: 6, carbs: 30, fat: 5 },
      { item: "Grilled Salmon", calories: 300, protein: 40, carbs: 0, fat: 15 }
    ];

    let responseBody;

    if (MOCK_MODE) {
      // ----------------------------
      // MOCK AI: pick highest-calorie items first
      // ----------------------------
      let totalCalories = 0;
      let totalProtein = 0;
      let totalCarbs = 0;
      let totalFat = 0;
      const meals = [];

      const sortedMenu = menuData.sort((a, b) => b.calories - a.calories);

      for (const item of sortedMenu) {
        if (totalCalories + item.calories <= calories) {
          meals.push(item.item);
          totalCalories += item.calories;
          totalProtein += item.protein || 0;
          totalCarbs += item.carbs || 0;
          totalFat += item.fat || 0;
        }
        if (totalCalories >= calories) break;
      }

      responseBody = {
        meals,
        total_calories: totalCalories,
        total_protein: totalProtein,
        total_carbs: totalCarbs,
        total_fat: totalFat,
      };
    } else {
      // ----------------------------
      // Bedrock AI code
      // ----------------------------
      const client = new BedrockRuntimeClient({ region: "us-east-1" });
      const prompt = `
You are a meal planner for UCLA dining hall food.
Menu: ${JSON.stringify(menuData)}
Calorie goal: ${calories}

Prioritize hitting the calorie goal above all else.
Protein, carbs, and fat are optional.
Return JSON like this:
{
  "meals": ["item1", "item2", ...],
  "total_calories": number,
  "total_protein": number,
  "total_carbs": number,
  "total_fat": number
}
      `;
      const command = new InvokeModelCommand({
        modelId: "amazon.titan-text-express-v1",
        body: JSON.stringify({
          inputText: prompt,
          textGenerationConfig: {
            maxTokenCount: 300,
            temperature: 0.1
          }
        }),
        contentType: "application/json",
        accept: "application/json",
      });

      const response = await client.send(command);
      const decoded = new TextDecoder().decode(response.body);
      const aiResponse = JSON.parse(decoded);
      const content = aiResponse.results[0].outputText;
      
      // Extract JSON from AI response
      const jsonMatch = content.match(/\{[^}]+\}/s);
      if (jsonMatch) {
        responseBody = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('AI response invalid');
      }
    }

    res.status(200).json(responseBody);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Wrap express app for serverless
module.exports.handler = serverless(app);
